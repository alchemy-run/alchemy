const version = "v2";
const server = Bun.serve({
  port: Number(process.env.PORT ?? "8080"),
  fetch(request) {
    console.log(`alchemy deployment fixture ${version} served ${new URL(request.url).pathname}`);
    return new Response(version);
  },
});
console.log(`alchemy deployment fixture ${version} listening on ${server.port}`);
