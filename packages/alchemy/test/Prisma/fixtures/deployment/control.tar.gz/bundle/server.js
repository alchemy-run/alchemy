// Answers "control". `/hold?seconds=N` (N <= 300) makes the next SIGTERM
// exit only after N seconds, so a stop stays in `stopping` that long.
let holdSeconds = 0;
process.on("SIGTERM", () => {
  console.log(`alchemy deployment fixture control: SIGTERM, exiting in ${holdSeconds}s`);
  setTimeout(() => process.exit(0), holdSeconds * 1000);
});
Bun.serve({
  port: Number(process.env.PORT ?? "8080"),
  fetch(request) {
    const url = new URL(request.url);
    if (url.pathname === "/hold") {
      holdSeconds = Math.min(300, Math.max(0, Number(url.searchParams.get("seconds") ?? "0")));
      return new Response(`holding ${holdSeconds}s`);
    }
    return new Response("control");
  },
});
